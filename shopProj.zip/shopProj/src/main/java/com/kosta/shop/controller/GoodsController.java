package com.kosta.shop.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.kosta.shop.dto.Goods;
import com.kosta.shop.service.GoodsService;

@Controller
public class GoodsController {
	
	@Autowired
	private GoodsService goodsService;
	
	@RequestMapping("/goodsRetrieve")
	public ModelAndView goodsRetrieve(@RequestParam("gCode") String gCode) {
		ModelAndView mav = new ModelAndView();
		try {
			Goods goods = goodsService.goodsRetrieve(gCode);
			mav.addObject("item", goods); 
			//<input type="hidden" name="gImage" value="${item.gImage}">
			mav.setViewName("goodsRetrieve");
		} catch (Exception e) {
			e.printStackTrace();
			mav.addObject("action", "��ǰ �� ��ȸ");
			mav.addObject("message", "��ǰ �� ��ȸ ����");
			mav.setViewName("memberResult");
		}
		return mav;		
	}
	
//	@RequestMapping("/goodsRetrieve")
//	public ModelAndView goodsRetrieve(@RequestParam("gCode") String gCode) {
//		ModelAndView mav = new ModelAndView();
////		System.out.println(gCode);
//		try {
//			Goods goods = goodsService.goodsDetail(gCode);
//			mav.addObject("goods", goods);
//			System.out.println(goods);
//			mav.setViewName("goodsRetrieve");
//		} catch (Exception e) {
//			e.printStackTrace();
//			mav.addObject("action", "��ǰ �Ѱ� ��ȸ");
//			mav.addObject("message", "��ǰ �Ѱ� ��ȸ ����");
//			mav.setViewName("memberResult");
//		}
//		return mav;
//	}
	
}
