package com.kosta.shop.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kosta.shop.dao.MemberDao;
import com.kosta.shop.dto.Member;

@Service
public class MemberServiceImpl implements MemberService {
	
	@Autowired
	private MemberDao memberDao;

	@Override
	public Member login(String userid, String passwd) throws Exception {
		Member member = memberDao.selectMember(userid);		
		if (member == null) {
			throw new Exception("���̵� ����");
		}
		if (!passwd.equals(member.getPasswd())) {
			throw new Exception("��й�ȣ ����");
		}
		return member;
	}

	@Override
	public void signUp(Member member) throws Exception {
		memberDao.insertMember(member);		
	}

	@Override
	public boolean idCheck(String userid) throws Exception {
		Integer cnt = memberDao.idCheck(userid);
		return cnt != 0;
	}

}
